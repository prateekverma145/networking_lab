TO RUN TCP
g++  tcp_server -o tcp_server
./tcp_server 

g++  tcp_client -o tcp_server
./tcp_client <ip>


TO RUN UDP
g++  udp_server -o udp_server
./udp_server 

g++  udp_client -o udp_server
./udp_client <ip>



COMMANDS:
MKD:  for making directory
CWD: change the currrent working directory
PWD: print current working directory
LIST: list the file in current dir
STOR <filename>: upload file to server
RETR <filename>: download from srever
QUIT: exit


max file size: 30KB
